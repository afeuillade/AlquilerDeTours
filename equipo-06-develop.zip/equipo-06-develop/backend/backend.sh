TEST="I'm a backend test II"
echo $TEST
version=$(cat VERSION)
echo $version