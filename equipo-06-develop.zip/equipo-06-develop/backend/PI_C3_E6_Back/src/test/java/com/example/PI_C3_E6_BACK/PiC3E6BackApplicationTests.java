package com.example.PI_C3_E6_BACK;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PiC3E6BackApplicationTests {

	@Test
	void contextLoads() {
	}

}
