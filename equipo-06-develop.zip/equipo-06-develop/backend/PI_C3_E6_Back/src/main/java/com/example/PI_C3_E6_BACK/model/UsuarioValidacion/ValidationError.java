package com.example.PI_C3_E6_BACK.model.UsuarioValidacion;

public record ValidationError(String field,String error) {
}
