package com.example.PI_C3_E6_BACK.exceptions;

public class BearerTokenException extends RuntimeException{
    public BearerTokenException(String message) {
        super(message);
    }
}
