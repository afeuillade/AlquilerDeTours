package com.example.PI_C3_E6_BACK.model;

import java.io.Serializable;

public class CaracteristicaDTO implements Serializable {
    private int id;

}
