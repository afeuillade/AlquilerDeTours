import React from 'react';
import './Spinner.css';

function Spinner() {
  return <div className="spinner" style={{ marginTop: '20px' }}></div>;
}

export default Spinner;